import { RouterConfiguration, Router } from "aurelia-router";
import { routes } from "./route";

export class App {
  router: Router;

  configureRouter(config: RouterConfiguration, router: Router) {
    this.router = router;
    config.title = "Hahn.ApplicatonProcess.May2020 - Muthu";
    config.map(routes);
  }
}
