var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Router } from 'aurelia-router';
import { inject } from 'aurelia-framework';
import { Applicant } from '../../models/applicant';
import { ApplicantService } from '../../services/applicant-service';
var Detail = (function () {
    function Detail(route, applicantService) {
        this.route = route;
        this.applicantService = applicantService;
        this.applicant = new Applicant();
    }
    Detail.prototype.getApplicant = function (id) {
        var _this = this;
        this.applicantService.getApplicant(id)
            .then(function (data) { return _this.applicant = data; });
    };
    Detail.prototype.activate = function (params) {
        this.getApplicant(params.id);
    };
    Detail.prototype.edit = function (id) {
        this.route.navigate('#/form/' + id);
    };
    Detail.prototype.goToList = function () {
        this.route.navigate('#/');
    };
    Detail.prototype.remove = function (id) {
        var _this = this;
        this.applicantService.deleteApplicant(id)
            .then(function () { return _this.goToList(); });
    };
    Detail = __decorate([
        inject(Router, ApplicantService),
        __metadata("design:paramtypes", [Router, ApplicantService])
    ], Detail);
    return Detail;
}());
export { Detail };
//# sourceMappingURL=detail.js.map