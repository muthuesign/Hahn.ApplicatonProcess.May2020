﻿import { Router } from 'aurelia-router';
import { inject } from 'aurelia-framework';
import { Applicant } from '../../models/applicant';
import { ApplicantService } from '../../services/applicant-service';

@inject(Router, ApplicantService)
export class Detail {

  public applicant: Applicant;

  constructor(private route: Router, private applicantService: ApplicantService) {
    this.applicant = new Applicant();
  }

  getApplicant(id: number) {
    this.applicantService.getApplicant(id)
      .then(data => this.applicant = data);
  }

  activate(params) {
    this.getApplicant(params.id);
  }

  edit(id: number) {
    this.route.navigate('#/form/' + id);
  }

  goToList() {
    this.route.navigate('#/');
  }

  remove(id: number) {
    this.applicantService.deleteApplicant(id)
      .then(() => this.goToList());
  }
}
