var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { inject } from 'aurelia-framework';
import { HttpClient, json } from 'aurelia-fetch-client';
import { I18N } from 'aurelia-i18n';
import { Shared } from './shared';
var ApplicantService = (function () {
    function ApplicantService(httpClient, i18n, shared) {
        this.httpClient = httpClient;
        this.i18n = i18n;
        this.shared = shared;
        this.baseUrl = '/api/applicant';
        this.httpClient.configure(function (config) {
            config
                .withDefaults({
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            });
        });
    }
    ApplicantService.prototype.getApplicants = function () {
        return this.httpClient.fetch(this.baseUrl + '?culture=' + this.i18n.getLocale())
            .then(function (response) { return response.json(); }).catch(this.handleError.bind(this));
    };
    ApplicantService.prototype.getApplicant = function (id) {
        return this.httpClient.fetch(this.baseUrl + "/" + id + '?culture=' + this.i18n.getLocale())
            .then(function (response) { return response.json(); }).catch(this.handleError.bind(this));
    };
    ApplicantService.prototype.addApplicant = function (applicant) {
        return this.httpClient.fetch(this.baseUrl + '?culture=' + this.i18n.getLocale(), {
            method: 'POST',
            body: json(applicant)
        })
            .then(function (response) { return response.json(); }).catch(this.handleError.bind(this));
    };
    ApplicantService.prototype.updateApplicant = function (id, applicant) {
        return this.httpClient.fetch(this.baseUrl + "/" + id + '?culture=' + this.i18n.getLocale(), {
            method: 'PUT',
            body: json(applicant)
        }).catch(this.handleError.bind(this));
    };
    ApplicantService.prototype.deleteApplicant = function (id) {
        return this.httpClient.fetch(this.baseUrl + "/" + id + '?culture=' + this.i18n.getLocale(), { method: 'DELETE' })
            .catch(this.handleError.bind(this));
    };
    ApplicantService.prototype.handleError = function (err) {
        console.error(err);
        this.shared.alertDialog({
            message: this.i18n.tr('applicant_layout.page_error'),
            lock: false,
            title: this.i18n.tr('applicant_layout.dlg_error')
        });
    };
    ApplicantService = __decorate([
        inject(HttpClient, I18N, Shared),
        __metadata("design:paramtypes", [HttpClient, I18N, Shared])
    ], ApplicantService);
    return ApplicantService;
}());
export { ApplicantService };
//# sourceMappingURL=applicant-service.js.map