var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { inject } from 'aurelia-framework';
import { I18N } from 'aurelia-i18n';
import { HttpClient } from 'aurelia-fetch-client';
import { constants } from '../shared/contants';
import { ValidationRules } from 'aurelia-validation';
import { Applicant } from "../models/applicant";
import { MsgDialog } from '../shared/msg-dialog';
import { DialogService } from 'aurelia-dialog';
var http = new HttpClient();
var Shared = (function () {
    function Shared(i18n, dialogService) {
        this.i18n = i18n;
        this.dialogService = dialogService;
        this.countries = new Array();
    }
    Shared.prototype.resetValidationRules = function () {
        ValidationRules.customRule('validCountry', function (value) {
            return http.fetch(constants.countryOfOriginCheckUrl + 'name/' + value + '?fullText=true')
                .then(function (response) { return 200 === response.status; });
        }, this.i18n.tr('applicant_layout.validations.valid'));
        var required = this.i18n.tr('applicant_layout.validations.required');
        ValidationRules
            .ensure(function (a) { return a.name; }).displayName(this.i18n.tr('applicant_layout.fld_name')).required().withMessage(required).minLength(5).withMessage(this.i18n.tr('applicant_layout.validations.minLength5'))
            .ensure(function (a) { return a.familyName; }).displayName(this.i18n.tr('applicant_layout.fld_family_name')).required().withMessage(required).minLength(5).withMessage(this.i18n.tr('applicant_layout.validations.minLength5'))
            .ensure(function (a) { return a.address; }).displayName(this.i18n.tr('applicant_layout.fld_address')).required().withMessage(required).minLength(10).withMessage(this.i18n.tr('applicant_layout.validations.minLength10'))
            .ensure(function (a) { return a.countryOfOrigin; }).displayName(this.i18n.tr('applicant_layout.fld_country_of_origin')).required().withMessage(required).then().satisfiesRule('validCountry')
            .ensure(function (a) { return a.eMailAdress; }).displayName(this.i18n.tr('applicant_layout.fld_email')).required().withMessage(required).matches(new RegExp(/^[A-Z0-9_'%=+!`#~$*?^{}&|-]+([\.][A-Z0-9_'%=+!`#~$*?^{}&|-]+)*@[A-Z0-9-]+(\.[A-Z0-9-]+)+$/i)).withMessage(this.i18n.tr('applicant_layout.validations.valid'))
            .ensure(function (a) { return a.age; }).displayName(this.i18n.tr('applicant_layout.fld_age')).required().withMessage(required).then().range(20, 60).withMessage(this.i18n.tr('applicant_layout.validations.range20_60'))
            .on(Applicant);
    };
    Shared.prototype.confirmDialog = function (context) {
        context.lock = true;
        return this.dialogService.open({
            viewModel: MsgDialog, model: context, lock: true
        });
    };
    Shared.prototype.alertDialog = function (context) {
        context.lock = false;
        return this.dialogService.open({
            viewModel: MsgDialog, model: context, lock: false
        });
    };
    Shared = __decorate([
        inject(I18N, DialogService),
        __metadata("design:paramtypes", [I18N, DialogService])
    ], Shared);
    return Shared;
}());
export { Shared };
//# sourceMappingURL=shared.js.map