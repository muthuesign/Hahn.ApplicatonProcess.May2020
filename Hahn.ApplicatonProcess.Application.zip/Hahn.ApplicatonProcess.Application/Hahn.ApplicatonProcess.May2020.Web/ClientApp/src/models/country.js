var Country = (function () {
    function Country() {
    }
    return Country;
}());
export { Country };
//# sourceMappingURL=country.js.map