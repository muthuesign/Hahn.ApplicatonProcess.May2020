var Applicant = (function () {
    function Applicant() {
    }
    return Applicant;
}());
export { Applicant };
//# sourceMappingURL=applicant.js.map