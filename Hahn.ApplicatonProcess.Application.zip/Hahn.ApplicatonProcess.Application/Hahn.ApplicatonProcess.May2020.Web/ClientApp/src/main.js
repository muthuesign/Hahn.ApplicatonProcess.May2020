import * as environment from '../config/environment.json';
import { PLATFORM } from 'aurelia-pal';
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap";
import "font-awesome/css/font-awesome.css";
import { TCustomAttribute } from 'aurelia-i18n';
import Backend from 'i18next-xhr-backend';
export function configure(aurelia) {
    aurelia.use
        .standardConfiguration()
        .feature(PLATFORM.moduleName('resources/index'))
        .plugin(PLATFORM.moduleName('aurelia-i18n'), function (instance) {
        var aliases = ['t', 'i18n'];
        TCustomAttribute.configureAliases(aliases);
        instance.i18next.use(Backend);
        return instance.setup({
            fallbackLng: 'en',
            whitelist: ['en', 'de'],
            preload: ['en', 'de'],
            attributes: aliases,
            lng: 'en',
            debug: true,
            backend: {
                loadPath: './dist/locales/{{lng}}/{{ns}}.json',
            }
        });
    })
        .plugin(PLATFORM.moduleName('aurelia-validation'))
        .plugin(PLATFORM.moduleName('aurelia-dialog'));
    aurelia.use.developmentLogging(environment.debug ? 'debug' : 'warn');
    if (environment.testing) {
        aurelia.use.plugin(PLATFORM.moduleName('aurelia-testing'));
    }
    aurelia.start().then(function () { return aurelia.setRoot(PLATFORM.moduleName('app')); });
}
//# sourceMappingURL=main.js.map