import { DialogController } from 'aurelia-dialog';
var ConfirmDialog = (function () {
    function ConfirmDialog(controller) {
        this.person = { firstName: '' };
        this.controller = controller;
        this.controller.settings.lock = true;
    }
    ConfirmDialog.prototype.attached = function (param) {
        this.person = param;
    };
    ConfirmDialog.inject = [DialogController];
    return ConfirmDialog;
}());
export { ConfirmDialog };
//# sourceMappingURL=confirm-dialog.js.map