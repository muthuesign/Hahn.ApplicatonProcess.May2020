export var constants = {
    "countryOfOriginCheckUrl": "https://restcountries.eu/rest/v2/"
};
//# sourceMappingURL=contants.js.map