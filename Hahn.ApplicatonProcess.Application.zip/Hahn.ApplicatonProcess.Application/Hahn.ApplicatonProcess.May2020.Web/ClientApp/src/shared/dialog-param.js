var DialogParam = (function () {
    function DialogParam() {
    }
    return DialogParam;
}());
export { DialogParam };
//# sourceMappingURL=dialog-param.js.map