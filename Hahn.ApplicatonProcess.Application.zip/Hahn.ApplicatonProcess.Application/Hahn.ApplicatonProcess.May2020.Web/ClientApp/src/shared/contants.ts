﻿export const constants = {
  "countryOfOriginCheckUrl": "https://restcountries.eu/rest/v2/"
};
