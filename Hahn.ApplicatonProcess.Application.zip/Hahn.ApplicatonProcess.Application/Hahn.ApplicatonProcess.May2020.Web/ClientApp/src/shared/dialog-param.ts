﻿export class DialogParam {
  title: string;
  message: string;
  lock: boolean;
}
