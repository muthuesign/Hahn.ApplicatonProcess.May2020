import { PLATFORM } from 'aurelia-pal';
export var routes = [
    {
        route: ["", "home"],
        name: "home",
        moduleId: PLATFORM.moduleName('components/applicant/list'),
        nav: true,
        title: "Home"
    },
    {
        route: ["form/:id?"],
        name: "appform",
        moduleId: PLATFORM.moduleName('components/applicant/appform'),
        nav: true,
        title: "Form",
        href: '#'
    },
    {
        route: ["detail/:id", "Detail"],
        name: "appDetail",
        moduleId: PLATFORM.moduleName('components/applicant/detail'),
        title: "Detail"
    }
];
//# sourceMappingURL=route.js.map