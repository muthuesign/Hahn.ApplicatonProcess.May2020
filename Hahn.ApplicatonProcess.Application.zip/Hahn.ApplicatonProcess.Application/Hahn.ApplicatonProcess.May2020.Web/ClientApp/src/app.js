import { routes } from "./route";
var App = (function () {
    function App() {
    }
    App.prototype.configureRouter = function (config, router) {
        this.router = router;
        config.title = "Hahn.ApplicatonProcess.May2020 - Muthu";
        config.map(routes);
    };
    return App;
}());
export { App };
//# sourceMappingURL=app.js.map