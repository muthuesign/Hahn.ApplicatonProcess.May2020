using FluentValidation.AspNetCore;
using Hahn.ApplicatonProcess.May2020.Data;
using Hahn.ApplicatonProcess.May2020.Web.Extensions;
using Hahn.ApplicatonProcess.May2020.Web.Filters;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Globalization;
using System.IO;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Logging;
using Serilog;

namespace Hahn.ApplicatonProcess.May2020.Web
{
  public class Startup
  {
    public IConfiguration Configuration { get; set; }
    public IWebHostEnvironment HostingEnvironment { get; set; }

    public Startup(IWebHostEnvironment env)
    {
      var builder = new ConfigurationBuilder()
          .SetBasePath(env.ContentRootPath)
          .AddJsonFile(env.ContentRootPath + $"/appsettings.json", optional: false)
          .AddJsonFile(env.ContentRootPath + $"/appsettings.{env.EnvironmentName}.json", true)
          .AddEnvironmentVariables();

      Configuration = builder.Build();
      HostingEnvironment = env;
    }

    // This method gets called by the runtime. Use this method to add services to the container.
    // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
    public void ConfigureServices(IServiceCollection services)
    {
      services.AddSingleton(Configuration);

      services.AddLocalization();

      services.AddMvcCore(opts => { opts.Filters.Add<GlobalExceptionFilter>(); })
                .AddApiExplorer()
                .AddFluentValidation();

      services.AddLogger(HostingEnvironment, Configuration);

      services.AddDbContext<HahnContext>(opt =>
          opt.UseInMemoryDatabase("HahnApplicant"));

      services.AddControllers().AddNewtonsoftJson();

      services.IocConfiguration(Configuration);

      services.AddSwagger();
    }

    // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
    public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
    {
      if (env.IsDevelopment())
      {
        app.UseDeveloperExceptionPage();
      }

      app.UseAppSwagger();

      Log.Logger = new LoggerConfiguration()
        .ReadFrom.Configuration(Configuration)
        .CreateLogger();

      loggerFactory.AddSerilog();

      var supportedCultures = new[]
      {
        new CultureInfo("en"),
        new CultureInfo("de"),
      };

      app.UseRequestLocalization(new RequestLocalizationOptions
      {
        DefaultRequestCulture = new RequestCulture("en"),
        // Formatting numbers, dates, etc.
        SupportedCultures = supportedCultures,
        // UI strings that we have localized.
        SupportedUICultures = supportedCultures
      });

      app.UseFileServer();

      app.UseRouting();
      
      app.UseEndpoints(endpoints =>
      {
        endpoints.MapControllers();
      });
    }
  }
}
