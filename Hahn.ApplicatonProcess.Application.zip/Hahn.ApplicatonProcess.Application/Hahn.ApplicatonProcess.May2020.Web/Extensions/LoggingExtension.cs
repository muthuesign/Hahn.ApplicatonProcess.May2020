﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hahn.ApplicatonProcess.May2020.Web.Extensions
{
    public static class LoggingExtension
    {
        public static void AddLogger(this IServiceCollection services, IWebHostEnvironment hostingEnvironment,
            IConfiguration configuration)
        {
            services.AddLogging(config =>
            {
                config.AddConfiguration(configuration.GetSection("Logging"));
            });
        }
    }
}
