﻿using System.Net.Http;
using FluentValidation;
using Hahn.ApplicatonProcess.May2020.Data;
using Hahn.ApplicatonProcess.May2020.Domain;
using Hahn.ApplicatonProcess.May2020.Domain.Common;
using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Hahn.ApplicatonProcess.May2020.Domain.Validators;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Hahn.ApplicatonProcess.May2020.Web.Extensions
{
    public static class IocExtension
    {
        public static void IocConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddOptions();
            services.Configure<ApplicationSettings>(configuration);
            services.AddTransient<HttpClient>();

            //Domain
            services.AddScoped<IValidator<Applicant>, ApplicantValidator>();

            //DATA
            services.AddTransient<IApplicantRepository, ApplicantRepository>();
        }
    }
}
