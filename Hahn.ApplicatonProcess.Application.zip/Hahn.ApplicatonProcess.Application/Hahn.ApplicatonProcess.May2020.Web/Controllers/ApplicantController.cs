﻿using System.Threading.Tasks;
using Hahn.ApplicatonProcess.May2020.Domain;
using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Microsoft.AspNetCore.Mvc;

namespace Hahn.ApplicatonProcess.May2020.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicantController : ControllerBase
    {
        private readonly IApplicantRepository _applicantRepository;

        public ApplicantController(IApplicantRepository applicantRepository)
        {
            _applicantRepository = applicantRepository;
        }

        [HttpGet]
        public async Task<ActionResult<Applicant>> Get()
        {
          return Ok(await _applicantRepository.Get());
        }

        [HttpGet("{id}", Name = "Get")]
        public async Task<ActionResult<Applicant>> Get(int id)
        {
            var applicant = await _applicantRepository.Get(id);

            if (applicant == null) return NotFound();

            return Ok(applicant);
        }

        [HttpPost]
        public async Task<ActionResult> Post([FromBody] Applicant applicant)
        {
            if (!ModelState.IsValid) return BadRequest();

            var response = await _applicantRepository.Add(applicant);
            return CreatedAtAction(nameof(Get), new {id = response.ID}, response);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromBody] Applicant applicant)
        {
            if (!ModelState.IsValid) return BadRequest();

            var response = await _applicantRepository.Update(id, applicant);
            if (response == null)
                return NotFound();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            var response = await _applicantRepository.Delete(id);
            if (response == null)
                return NotFound();

            return NoContent();
        }
    }
}
