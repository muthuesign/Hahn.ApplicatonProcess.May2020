﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hahn.ApplicatonProcess.May2020.Domain;
using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Newtonsoft.Json.Linq;

namespace Hahn.ApplicatonProcess.May2020.Data
{
    public class ApplicantRepository : IApplicantRepository
    {
        private readonly HahnContext _hahnContext;
        public ApplicantRepository(HahnContext hahnContext)
        {
            _hahnContext = hahnContext;
        }

        public async Task<Applicant> Add(Applicant applicant)
        {
            var response = await _hahnContext.ApplicantEntities.AddAsync(applicant);
            await _hahnContext.SaveChangesAsync();

            return response.Entity;
        }

        public async Task<Applicant> Delete(int id)
        {
            var applicant =  _hahnContext.ApplicantEntities.SingleOrDefault(a => a.ID == id);

            if (applicant == null) return null;

            _hahnContext.ApplicantEntities.Remove(applicant);
            await _hahnContext.SaveChangesAsync();

            return applicant;
        }

        public async Task<IQueryable<Applicant>> Get()
        {
            var applicants = await Task.FromResult(_hahnContext.ApplicantEntities.AsQueryable());
            return applicants;
        }

        public async Task<Applicant> Get(int id)
        {
           return await _hahnContext.ApplicantEntities.FindAsync(id);
        }

        public async Task<Applicant> Update(int id, Applicant applicant)
        {
            var extApplicant = await _hahnContext.ApplicantEntities.FindAsync(id);

            if (extApplicant == null) return null;

            //extApplicant.Name = applicant.Name;
            //extApplicant.FamilyName = applicant.FamilyName;
            //extApplicant.Address = applicant.Address;
            //extApplicant.CountryOfOrigin = applicant.CountryOfOrigin;
            //extApplicant.EMailAdress = applicant.EMailAdress;
            //extApplicant.Age = applicant.Age;
            //extApplicant.Hired = applicant.Hired;

            _hahnContext.Entry(extApplicant).CurrentValues.SetValues(applicant);

            _hahnContext.SaveChanges();

            return extApplicant;
        }
    }
}
