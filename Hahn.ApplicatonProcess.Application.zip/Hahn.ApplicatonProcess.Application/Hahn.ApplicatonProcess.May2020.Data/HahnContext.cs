﻿using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace Hahn.ApplicatonProcess.May2020.Data
{
    public class HahnContext : DbContext
    {
        public HahnContext(DbContextOptions<HahnContext> options)
            : base(options)
        {
        }

        public DbSet<Applicant> ApplicantEntities { get; set; }
    }
}
