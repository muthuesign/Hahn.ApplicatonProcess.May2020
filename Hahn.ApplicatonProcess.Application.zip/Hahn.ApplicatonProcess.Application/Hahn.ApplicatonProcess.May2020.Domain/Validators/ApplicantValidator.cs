﻿using System.Net.Http;
using System.Threading.Tasks;
using FluentValidation;
using Hahn.ApplicatonProcess.May2020.Domain.Common;
using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using Hahn.ApplicatonProcess.May2020.Domain.Resources;

namespace Hahn.ApplicatonProcess.May2020.Domain.Validators
{
    public class ApplicantValidator : AbstractValidator<Applicant>
    {
        private readonly ApplicationSettings _applicationSettings;
        private readonly HttpClient _httpClient;

        public ApplicantValidator(IOptions<ApplicationSettings> applicationSettings, HttpClient httpClient, IStringLocalizer<SharedResources> localizer)
        {
            _applicationSettings = applicationSettings.Value;
            _httpClient = httpClient;

            RuleFor(app => app.Name).MinimumLength(5).WithMessage(string.Format(localizer["NameMinLength"].Value, 5));
            RuleFor(app => app.FamilyName).MinimumLength(5).WithMessage(string.Format(localizer["FamilyNameMinLength"], 5));
            RuleFor(app => app.Address).MinimumLength(10).WithMessage(string.Format(localizer["AddressMinLength"], 10));
            RuleFor(app => app.CountryOfOrigin).MustAsync((country, cancellation) => IsValidCountryOfOrigin(country))
                .WithMessage(localizer["CountryOfOriginValid"].Value);
            RuleFor(app => app.EMailAdress).EmailAddress().WithMessage(localizer["EMailAddressValid"].Value);
            RuleFor(app => app.Age).InclusiveBetween(20, 60).WithMessage(string.Format(localizer["AgeRange"], 20, 60));
        }

        private async Task<bool> IsValidCountryOfOrigin(string countryOfOrigin)
        {
            var response = await _httpClient.GetAsync($"{_applicationSettings.CountryOfOriginCheckUrl}name/{countryOfOrigin}?fullText=true");
            return response.IsSuccessStatusCode;
        }
    }
}
