﻿
using System.ComponentModel;

namespace Hahn.ApplicatonProcess.May2020.Domain.Models
{
    public class Applicant
    {
        public int ID { get; set; }
        [DefaultValue("Muthukrishnan")]
        public string Name { get; set; }
        [DefaultValue("Rangasamy")]
        public string FamilyName { get; set; }
        [DefaultValue("Coimbatore, TN, India")]
        public string Address { get; set; }
        [DefaultValue("India")]
        public string CountryOfOrigin { get; set; }
        [DefaultValue("muthujune1987@gmail.com")]
        public string EMailAdress { get; set; }
        [DefaultValue(32)]
        public int Age { get; set; }
        [DefaultValue(false)]
        public bool Hired { get; set; }
    }
}
