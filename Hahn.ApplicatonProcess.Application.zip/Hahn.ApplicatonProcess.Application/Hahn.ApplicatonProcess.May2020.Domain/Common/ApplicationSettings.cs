﻿
namespace Hahn.ApplicatonProcess.May2020.Domain.Common
{
    public class ApplicationSettings
    {
        public string CountryOfOriginCheckUrl { get; set; }
    }
}
