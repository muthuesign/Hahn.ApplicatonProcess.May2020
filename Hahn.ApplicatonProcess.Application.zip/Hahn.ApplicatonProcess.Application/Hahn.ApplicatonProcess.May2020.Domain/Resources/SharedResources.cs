﻿
namespace Hahn.ApplicatonProcess.May2020.Domain.Resources
{
    public class SharedResources
    {
    }
}
