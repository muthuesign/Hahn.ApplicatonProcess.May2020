﻿using System.Linq;
using System.Threading.Tasks;
using Hahn.ApplicatonProcess.May2020.Domain.Models;

namespace Hahn.ApplicatonProcess.May2020.Domain
{
    public interface IApplicantRepository
    {
        Task<IQueryable<Applicant>> Get();
        Task<Applicant> Get(int id);
        Task<Applicant> Add(Applicant applicant);
        Task<Applicant> Update(int id, Applicant applicant);
        Task<Applicant> Delete(int id);
    }
}
